const moviesData = require("./movies");
const commentsData = require("./comments");

module.exports = {
  movies: moviesData,
  comments: commentsData,
};
